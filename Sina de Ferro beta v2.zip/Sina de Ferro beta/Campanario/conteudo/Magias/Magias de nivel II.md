Magias de Nível II liberam no **nível 8** (ver seção 6.5) e custam **2 Espaços de Magia** para aprender. São o degrau intermediário: efeitos mais confiáveis, dano mais consistente, e as primeiras magias que acionam **Efeitos Elementais** (seção 6.6) de forma explícita — o tipo de coisa que Nível I não tinha orçamento pra fazer.

Seguem a mesma resolução da seção 6: **Magia de Dano** ataca a Defesa; **Magia de Controle** o alvo resiste.

> **Alcance padrão:** Curto, salvo indicação contrária. **Escala de custo:** em geral, 3 Mana é o "modelo padrão" (equivalente ao topo do Nível I, só que mais forte) e 4 Mana é a opção "premium" da categoria — com rider maior, área, ou efeito elemental embutido.

---

## Magias de Dano

### Lança de Gelo Cristalina

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Dano:** 3d6 + Intelecto, gelo — reduzido pela Redução de Dano Mágica do alvo.
- **Propriedade:** aplica o Efeito Elemental de Gelo (seção 6.6 — Frágil).
- A evolução direta da Lança de Gelo: mesmo golpe, agora rachando a própria Redução de Dano do alvo no impacto.

### Explosão Arcana

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Dano:** 2d8 + Intelecto, arcano, no alvo principal; todas as criaturas adjacentes a ele sofrem metade desse dano (arredondado para baixo).
- A primeira magia de dano em área verdadeira do repertório — pensada pra grupos de inimigos fracos, não pra um único alvo forte.

### Lança Ígnea

- **Atributo:** Intelecto | **Custo:** 4 Mana
- **Dano:** 3d8 + Intelecto, fogo — reduzido pela Redução de Dano Mágica do alvo.
- **Propriedade:** aplica o Efeito Elemental de Fogo (seção 6.6 — Queimando).

### Corrente Relâmpago

- **Atributo:** Vontade | **Custo:** 4 Mana
- **Dano:** 2d8 + Vontade, elétrico, no alvo principal; salta para um segundo alvo adjacente ao primeiro, causando metade do dano.
- **Propriedade:** se o teste de ataque contra o alvo principal for crítico, ambos os alvos sofrem o Efeito Elemental de Raio (seção 6.6 — Choque).

### Foice das Sombras

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Dano:** 2d10 + Vontade, sombrio — ignora 2 pontos da Redução de Dano Mágica do alvo.
- Menos dado que a Lança Ígnea, mas passa direto por armaduras mágicas que outras magias não conseguem furar.

### Lança de Terra

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Dano:** 4d4 + Intelecto, terra — reduzido pela Redução de Dano Mágica do alvo.
- **Propriedade:** aplica o Efeito Elemental de Terra (seção 6.6 — Lentificado), além de explodir no impacto e causar metade do dano nos alvos adjacentes

### Vapor Corrosivo

- **Atributo:** Intelecto | **Custo:** 4 Mana
- **Dano:** 2d8 + Intelecto, ácido, no alvo principal; todas as criaturas adjacentes a ele sofrem metade desse dano (arredondado para baixo), e o efeito fica na area por mais duas rodadas, aplicando o efeito de Ácido a quem entrar ou passar pela área.
- **Propriedade:** o alvo principal sofre o Efeito Elemental de Ácido (seção 6.6 — Corroído).

### Mordida Venenosa

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Dano:** 2d8 + Vontade, veneno — reduzido pela Redução de Dano Mágica do alvo.
- **Propriedade:** aplica o Efeito Elemental de Veneno (seção 6.6 — Envenenado).

### Estilhaço Ígneo

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Dano:** 3d6 + Intelecto, fogo — reduzido pela Redução de Dano Mágica do alvo.
- O modelo padrão de dano de fogo do Nível II — mais barato que a Lança Ígnea, sem o Efeito Elemental embutido.

### Estrondo Sônico

- **Atributo:** Vontade | **Custo:** 4 Mana
- **Dano:** 3d8 + Vontade, sônico, em área curta — reduzido pela Redução de Dano Mágica de cada alvo atingido.
- **Propriedade:** cada alvo atingido sofre desvantagem no próximo teste de Iniciativa que fizer, atordoado pelo estrondo mesmo sem ficar Atordoado de fato.

---

## Magias de Controle

### Paralisia Momentânea

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** o alvo resiste com Vigor ou fica **Paralisado** (não pode agir, sofre desvantagem em qualquer Reação) até o início do seu próximo turno.

### Prisão de Gelo

- **Atributo:** Intelecto | **Custo:** 4 Mana
- **Efeito:** o alvo resiste com Força ou fica **Agarrado e Enredado** por 2 rodadas — precisa de uma Ação padrão em cada turno pra tentar se soltar (novo teste de Força vs a mesma DT).

### Comando Breve

- **Atributo:** Vontade | **Custo:** 4 Mana
- **Efeito:** o alvo resiste com Vontade ou obedece um único comando simples de uma palavra ("ataque", "fuja", "solte", "pare") no início do seu próximo turno. Não funciona contra ordens claramente suicidas ou contra a própria natureza do alvo.

### Silêncio Absoluto

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** o alvo resiste com Vontade ou fica incapaz de conjurar magias ou usar qualquer habilidade que custe Mana, por 2 rodadas.

#### Golpe Atordoante

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** o alvo resiste com Vigor ou fica **Atordoado** por 2 rodadas

#### Terreno Instável

- **Atributo:** Intelecto | **Custo:** 4 Mana
- **Efeito:** todos os inimigos em área curta resistem com Velocidade ou ficam **Derrubados**.

### Névoa Cegante

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** o alvo resiste com Atenção ou fica **Cego** por 2 rodadas — a versão prolongada do Véu Cego de Nível I.

### Pavor em Área

- **Atributo:** Vontade | **Custo:** 4 Mana
- **Efeito:** todos os inimigos em área curta resistem com Vontade ou ficam **Amedrontados** por 1 rodada.

---

## Magias de Utilidade

### Portal Curto

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** o conjurador se teleporta instantaneamente para um espaço visível dentro de Alcance Médio.

### Forma Etérea Passageira

- **Atributo:** Vontade | **Custo:** 4 Mana
- **Efeito:** o conjurador se torna incorpóreo por 1 rodada — atravessa terreno e objetos sólidos, e ataques físicos não o afetam (ataques mágicos continuam funcionando normalmente).

### Olhos à Distância

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** cria um sensor invisível e imóvel dentro de Alcance Longo, através do qual o conjurador pode ver e ouvir, por até 10 minutos ou até ser dissipado (Ação padrão, à sua escolha).

### Compreensão Universal

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** por 1 hora, o conjurador compreende qualquer idioma falado ou escrito ao seu redor. Não permite falar ou escrever de volta em um idioma que não conheça.

### Disfarce Ilusório

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Efeito:** o conjurador (ou um aliado tocado) muda de aparência física para outra criatura humanoide de tamanho similar, por 10 minutos. A ilusão engana a visão, mas não resiste a toque ou exame cuidadoso.

### Passo Entre Sombras

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Efeito:** o conjurador troca de posição instantaneamente com um aliado consciente e disposto dentro de Alcance Médio.

---

## Cura

### Onda de Cura

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Efeito:** restaura 2d8 + Vontade de PV em um alvo ao alcance.

### Cura em Grupo

- **Atributo:** Vontade | **Custo:** 4 Mana
- **Efeito:** restaura 1d8 + metade da Vontade (arredondado para baixo) de PV a até 3 aliados ao alcance.

### Regeneração Maior

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Efeito:** um alvo ao alcance restaura 1d4 PV por turno, por 3 turnos.

### Abraço da Vontade

- **Atributo:** Vontade | **Custo:** 4 Mana
- **Efeito:** restaura 2d6 PV e remove uma condição negativa de um aliado ao alcance — a versão premium que combina cura e alívio num único gasto de Mana.

---

## Buffs

### Bênção do Aço

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** um aliado ao alcance recebe +3 Redução de Dano Física por 2 rodadas.

### Fúria Guiada

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Efeito:** um aliado ao alcance recebe +2 no próximo teste de ataque e +1d6 fixo de dano nesse mesmo ataque.

### Presteza Arcana

- **Atributo:** Intelecto | **Custo:** 4 Mana
- **Efeito:** um aliado ao alcance ganha uma **Ação Bônus** extra neste turno. Não pode ser usada pra conjurar uma segunda magia que exija Ação padrão.

### Manto da Sina

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Efeito:** um aliado ao alcance recebe +2 na Defesa e vantagem no próximo teste de resistência que fizer, até o início do seu próximo turno.

---

## Debuffs

### Maldição do Enfraquecimento

- **Atributo:** Intelecto | **Custo:** 3 Mana
- **Efeito:** o alvo resiste com Vigor ou sofre -3 na Redução de Dano Física e Mágica por 2 rodadas.

### Maldição da Fraqueza

- **Atributo:** Intelecto | **Custo:** 4 Mana
- **Efeito:** o alvo resiste com Vigor ou fica **Enfraquecido -3** (atributo à escolha do conjurador) por 2 rodadas.

### Grilhões Arcanos

- **Atributo:** Intelecto | **Custo:** 4 Mana
- **Efeito:** o alvo resiste com Força ou fica **Agarrado** e perde o acesso à Ação Reativa, por 2 rodadas.

### Sussurro do Pânico

- **Atributo:** Vontade | **Custo:** 3 Mana
- **Efeito:** o alvo resiste com Vontade ou fica **Amedrontado** e sofre desvantagem em testes de ataque, por 2 rodadas.